import React from 'react';
import './index.css';
// Components


export default class Audio extends React.Component {

    constructor() {
        super();
        this.state = (
            {
                playing: false
            }
        );
        this.handlePlay = this.handlePlay.bind(this);
        this.handlePause = this.handlePause.bind(this);
    }

    handlePlay = () => {
        this.setState(
            {
                playing: true
            }
        );
        let audio = this.refs.audio;
        audio.play();
    };

    handlePause = () => {
        this.setState(
            {
                playing: false
            }
        );
        let audio = this.refs.audio;
        audio.pause();
    };

    render() {
        return (
            <div className='music'>
                <div className='path'>
                    <audio
                        id='audio'
                        ref='audio'
                        src={this.props.src}
                    />
                </div>
                <div className='music-button'>

                    {
                        this.state.playing
                            ?
                            <button
                                className='music-button-pause'
                                onClick={this.handlePause}
                            />
                            :
                            <button
                                className='music-button-play'
                                onClick={this.handlePlay}
                            />
                    }

                    <div className='circle-container'>
                        <div className='circle'>
                            <svg width='40' height='40' viewBox='0 0 120 120'>
                                <circle cx='60' cy='60' r='54' fill='none' stroke='#e6e6e6' strokeWidth='10'/>
                                <circle cx='60' cy='60' r='54' fill='none' stroke='#2196f3' strokeWidth='10'
                                        strokeDasharray='339.292' strokeDashoffset='322.61197178968575'/>
                            </svg>
                        </div>
                    </div>
                </div>
                <div className='music-information'>
                    <div className='music-about'>
                        <p className='music-forename'>{this.props.forename}</p>
                        <p className='music-executor'>{this.props.executor}</p>
                    </div>
                    <div className='music-internal'>
                        <p className='music-time'>5:04</p>
                        <button className='button-speech'></button>
                    </div>
                </div>
            </div>
        );
    }

}