import React from 'react';
import './index.css';
// Components


export default class Control extends React.Component {

    componentDidMount() {
        // console.log(this.props.thematic);
    }

    render() {
        return (
            <div className='control'>
                <button className='button-repeat'></button>
                <div>
                    <button className='button-left'></button>
                    <button className='button-play'></button>
                    <button className='button-right'></button>
                </div>
                <button className='button-close'></button>
            </div>
        );
    }

}